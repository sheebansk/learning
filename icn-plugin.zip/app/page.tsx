"use client"

import  from "../WebContent/contentViewerPlugin"

export default function SyntheticV0PageForDeployment() {
  return < />
}