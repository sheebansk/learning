package com.glic.extensions.ContentViewerPlugin;

import java.util.Locale;

import com.ibm.ecm.extension.Plugin;
import com.ibm.ecm.extension.PluginAction;
import com.ibm.ecm.extension.PluginConfigurationParameters;
import com.ibm.ecm.extension.PluginFeature;
import com.ibm.ecm.extension.PluginLayout;
import com.ibm.ecm.extension.PluginMenu;
import com.ibm.ecm.extension.PluginMenuItem;
import com.ibm.ecm.extension.PluginOpenAction;
import com.ibm.ecm.extension.PluginRequestFilter;
import com.ibm.ecm.extension.PluginResponseFilter;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginViewerDef;

/**
 * Java plugin class for IBM Content Navigator
 * This class provides the server-side plugin configuration
 */
public class ContentViewerPlugin extends Plugin {

    @Override
    public String getId() {
        return "ContentViewerPlugin";
    }

    @Override
    public String getName(Locale locale) {
        return "Content Viewer Plugin";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }

    @Override
    public String getDojoModule() {
        return "contentViewerPlugin";
    }

    @Override
    public String getCopyright() {
        return "Copyright (c) 2024";
    }

    @Override
    public PluginAction[] getActions() {
        return new PluginAction[0];
    }

    @Override
    public PluginConfigurationParameters getConfigurationParameters() {
        return null;
    }

    @Override
    public PluginFeature[] getFeatures() {
        return new PluginFeature[0];
    }

    @Override
    public PluginLayout[] getLayouts() {
        return new PluginLayout[0];
    }

    @Override
    public PluginMenu[] getMenus() {
        return new PluginMenu[0];
    }

    @Override
    public PluginMenuItem[] getMenuItems() {
        return new PluginMenuItem[0];
    }

    @Override
    public PluginOpenAction[] getOpenActions() {
        return new PluginOpenAction[0];
    }

    @Override
    public PluginRequestFilter[] getRequestFilters() {
        return new PluginRequestFilter[0];
    }

    @Override
    public PluginResponseFilter[] getResponseFilters() {
        return new PluginResponseFilter[0];
    }

    @Override
    public PluginService[] getServices() {
        return new PluginService[0];
    }

    @Override
    public PluginViewerDef[] getViewerDefs() {
        return new PluginViewerDef[0];
    }

    @Override
    public String getScript() {
        return "contentViewerPlugin.ContentViewerPlugin";
    }

    @Override
    public String getDebugScript() {
        return getScript();
    }

    @Override
    public String getCSSFileName() {
        return "WebContent/contentViewerPlugin.css";
    }
}
