require([
  "dojo/_base/declare",
  "dojo/_base/lang",
  "dojo/aspect",
  "ecm/widget/layout/CommonActionsHandler",
  "ecm/widget/Button",
  "ecm/model/desktop",
  "ecm/LoggerMixin",
  "ecm/widget/layout/_MainLayout",
  "ecm/model/ContentItem",
  "ecm/model/Repository",
], (
  declare,
  lang,
  aspect,
  CommonActionsHandler,
  Button,
  desktop,
  LoggerMixin,
  _MainLayout,
  ContentItem,
  Repository,
) => {
  /**
   * Main plugin class for adding document navigation buttons to the header panel
   */
  var ContentViewerPlugin = declare("contentViewerPlugin.ContentViewerPlugin", [LoggerMixin], {
    id: "ContentViewerPlugin",
    name: "Content Viewer Plugin",
    version: "1.0.0",

    // Document navigation state
    _documentList: [],
    _currentDocumentIndex: -1,

    /**
     * Plugin load method - called when the plugin is loaded
     */
    load: function (callback) {
      this.logEntry("load")

      // Initialize document list
      this._documentList = []
      this._currentDocumentIndex = -1

      // Set up message event listener for external iframe communication
      this._setupMessageListener()

      // Wait for desktop to be ready and then add buttons to CommonActionsHandler
      if (desktop.isLoaded) {
        this._addButtonsToCommonHandler()
      } else {
        aspect.after(
          desktop,
          "onLogin",
          lang.hitch(this, function () {
            this._addButtonsToCommonHandler()
          }),
        )
      }

      if (callback) {
        callback()
      }

      this.logExit("load")
    },

    /**
     * Setup message event listener for external iframe communication
     */
    _setupMessageListener: function () {
      this.logEntry("_setupMessageListener")
      

      // Listen for messages from parent window (external iframe)
      window.addEventListener(
        "message",
        (event) => {
          try {
            this.logDebug("_setupMessageListener", "Received message: " + JSON.stringify(event.data))

            if (event.data && event.data.type) {
              switch (event.data.type) {
                case "DOCUMENT_LIST":
                  this._handleDocumentListMessage(event.data)
                  break
                case "OPEN_DOCUMENT":
                  this._handleOpenDocumentMessage(event.data)
                  break
                case "CURRENT_DOCUMENT":
                  this._handleCurrentDocumentMessage(event.data)
                  break
                default:
                  this.logDebug("_setupMessageListener", "Unknown message type: " + event.data.type)
              }
            }
          } catch (error) {
            this.logError("_setupMessageListener", "Error processing message: " + error.message)
          }
        },
        false,
      )

      this.logExit("_setupMessageListener")
    },

    /**
     * Handle document list message from external iframe
     */
    _handleDocumentListMessage: function (messageData) {
      this.logEntry("_handleDocumentListMessage")

      if (messageData.documents && Array.isArray(messageData.documents)) {
        this._documentList = messageData.documents
        this.logDebug(
          "_handleDocumentListMessage",
          "Updated document list with " + this._documentList.length + " documents",
        )

        // Update button states
        this._updateNavigationButtons()
      }

      this.logExit("_handleDocumentListMessage")
    },

    /**
     * Handle open document message from external iframe
     */
    _handleOpenDocumentMessage: function (messageData) {
      this.logEntry("_handleOpenDocumentMessage")

      if (messageData.document) {
        var docInfo = messageData.document
        this._openDocumentByInfo(docInfo.repositoryId, docInfo.docId, docInfo.vsId, docInfo.version)
      }

      this.logExit("_handleOpenDocumentMessage")
    },

    /**
     * Handle current document message from external iframe
     */
    _handleCurrentDocumentMessage: function (messageData) {
      this.logEntry("_handleCurrentDocumentMessage")

      if (messageData.document) {
        var docInfo = messageData.document
        this._setCurrentDocument(docInfo)
        this._updateNavigationButtons()
      }

      this.logExit("_handleCurrentDocumentMessage")
    },

    /**
     * Set current document and find its index in the document list
     */
    _setCurrentDocument: function (docInfo) {
      this.logEntry("_setCurrentDocument")

      // Find the document in the list
      for (var i = 0; i < this._documentList.length; i++) {
        var doc = this._documentList[i]
        if (
          doc.repositoryId === docInfo.repositoryId &&
          doc.docId === docInfo.docId &&
          doc.vsId === docInfo.vsId &&
          doc.version === docInfo.version
        ) {
          this._currentDocumentIndex = i
          this.logDebug("_setCurrentDocument", "Current document index set to: " + i)
          break
        }
      }

      this.logExit("_setCurrentDocument")
    },

    /**
     * Add custom buttons to the CommonActionsHandler
     */
    _addButtonsToCommonHandler: function () {
      this.logEntry("_addButtonsToCommonHandler")

      try {
        // Get the CommonActionsHandler instance
        var commonActionsHandler = CommonActionsHandler.singleton

        if (!commonActionsHandler) {
          this.logError("_addButtonsToCommonHandler", "CommonActionsHandler not found")
          return
        }

        // Add Previous button
        this._addPreviousButton(commonActionsHandler)

        // Add Next button
        this._addNextButton(commonActionsHandler)

        this.logDebug("_addButtonsToCommonHandler", "Navigation buttons added successfully")
      } catch (error) {
        this.logError("_addButtonsToCommonHandler", "Error adding buttons: " + error.message)
      }

      this.logExit("_addButtonsToCommonHandler")
    },

    /**
     * Add Previous button to CommonActionsHandler
     */
    _addPreviousButton: function (commonActionsHandler) {
      this.logEntry("_addPreviousButton")

      var previousButton = new Button({
        id: "contentViewerPreviousButton",
        label: "Previous",
        showLabel: true,
        iconClass: "ecmActionIcon ecmActionIconBack",
        onClick: lang.hitch(this, this._onPreviousClick),
        disabled: true, // Initially disabled
      })

      // Add to common actions handler
      if (commonActionsHandler.addAction) {
        commonActionsHandler.addAction({
          id: "contentViewerPrevious",
          widget: previousButton,
          context: "header",
        })
      } else {
        // Alternative approach - add to toolbar directly
        this._addButtonToToolbar(previousButton)
      }

      // Store reference for enabling/disabling
      this._previousButton = previousButton

      this.logExit("_addPreviousButton")
    },

    /**
     * Add Next button to CommonActionsHandler
     */
    _addNextButton: function (commonActionsHandler) {
      this.logEntry("_addNextButton")

      var nextButton = new Button({
        id: "contentViewerNextButton",
        label: "Next",
        showLabel: true,
        iconClass: "ecmActionIcon ecmActionIconForward",
        onClick: lang.hitch(this, this._onNextClick),
        disabled: true, // Initially disabled
      })

      // Add to common actions handler
      if (commonActionsHandler.addAction) {
        commonActionsHandler.addAction({
          id: "contentViewerNext",
          widget: nextButton,
          context: "header",
        })
      } else {
        // Alternative approach - add to toolbar directly
        this._addButtonToToolbar(nextButton)
      }

      // Store reference for enabling/disabling
      this._nextButton = nextButton

      this.logExit("_addNextButton")
    },

    /**
     * Alternative method to add button directly to toolbar
     */
    _addButtonToToolbar: function (button) {
      this.logEntry("_addButtonToToolbar")

      try {
        // Get the main layout
        var mainLayout = _MainLayout
        if (mainLayout && mainLayout.banner && mainLayout.banner.actionBar) {
          mainLayout.banner.actionBar.addChild(button)
          this.logDebug("_addButtonToToolbar", "Button added to action bar")
        } else if (mainLayout && mainLayout.banner) {
          // Add directly to banner DOM
          button.placeAt(mainLayout.banner.domNode, "last")
          button.startup()
          this.logDebug("_addButtonToToolbar", "Button added to banner DOM")
        }
      } catch (error) {
        this.logError("_addButtonToToolbar", "Error: " + error.message)
      }

      this.logExit("_addButtonToToolbar")
    },

    /**
     * Handle Previous button click
     */
    _onPreviousClick: function () {
      this.logEntry("_onPreviousClick")

      try {
        if (this._currentDocumentIndex > 0) {
          var previousDoc = this._documentList[this._currentDocumentIndex - 1]
          this.logDebug("_onPreviousClick", "Opening previous document: " + JSON.stringify(previousDoc))

          this._openDocumentByInfo(previousDoc.repositoryId, previousDoc.docId, previousDoc.vsId, previousDoc.version)

          // Update current index
          this._currentDocumentIndex--

          // Update button states
          this._updateNavigationButtons()

          // Notify parent window about navigation
          this._notifyParentWindow("NAVIGATE_PREVIOUS", previousDoc)
        } else {
          this.logDebug("_onPreviousClick", "No previous document available")
        }
      } catch (error) {
        this.logError("_onPreviousClick", "Error: " + error.message)
      }

      this.logExit("_onPreviousClick")
    },

    /**
     * Handle Next button click
     */
    _onNextClick: function () {
      this.logEntry("_onNextClick")

      try {
        if (this._currentDocumentIndex < this._documentList.length - 1) {
          var nextDoc = this._documentList[this._currentDocumentIndex + 1]
          this.logDebug("_onNextClick", "Opening next document: " + JSON.stringify(nextDoc))

          this._openDocumentByInfo(nextDoc.repositoryId, nextDoc.docId, nextDoc.vsId, nextDoc.version)

          // Update current index
          this._currentDocumentIndex++

          // Update button states
          this._updateNavigationButtons()

          // Notify parent window about navigation
          this._notifyParentWindow("NAVIGATE_NEXT", nextDoc)
        } else {
          this.logDebug("_onNextClick", "No next document available")
        }
      } catch (error) {
        this.logError("_onNextClick", "Error: " + error.message)
      }

      this.logExit("_onNextClick")
    },

    /**
     * Open document by repository ID, document ID, version series ID, and version
     */
    _openDocumentByInfo: function (repositoryId, docId, vsId, version) {
      this.logEntry("_openDocumentByInfo", "repositoryId: " + repositoryId + ", docId: " + docId)

      try {
        // Get the repository
        var repository = desktop.getRepository(repositoryId)
        if (!repository) {
          this.logError("_openDocumentByInfo", "Repository not found: " + repositoryId)
          return
        }

        // Create content item
        var contentItem = new ContentItem({
          id: docId,
          vsId: vsId,
          version: version,
          repository: repository,
        })

        // Open the document
        if (desktop.openDocument) {
          desktop.openDocument(contentItem)
          this.logDebug("_openDocumentByInfo", "Document opened successfully")
        } else {
          this.logError("_openDocumentByInfo", "desktop.openDocument method not available")
        }
      } catch (error) {
        this.logError("_openDocumentByInfo", "Error opening document: " + error.message)
      }

      this.logExit("_openDocumentByInfo")
    },

    /**
     * Notify parent window about navigation events
     */
    _notifyParentWindow: function (eventType, documentInfo) {
      this.logEntry("_notifyParentWindow", eventType)

      try {
        if (window.parent && window.parent !== window) {
          var message = {
            type: eventType,
            document: documentInfo,
            source: "ICN_CONTENT_VIEWER_PLUGIN",
          }

          window.parent.postMessage(message, "*")
          this.logDebug("_notifyParentWindow", "Message sent to parent: " + JSON.stringify(message))
        }
      } catch (error) {
        this.logError("_notifyParentWindow", "Error sending message to parent: " + error.message)
      }

      this.logExit("_notifyParentWindow")
    },

    /**
     * Update navigation button states based on current context
     */
    _updateNavigationButtons: function () {
      this.logEntry("_updateNavigationButtons")

      var canGoPrevious = this._canNavigatePrevious()
      var canGoNext = this._canNavigateNext()

      if (this._previousButton) {
        this._previousButton.set("disabled", !canGoPrevious)
      }

      if (this._nextButton) {
        this._nextButton.set("disabled", !canGoNext)
      }

      this.logDebug(
        "_updateNavigationButtons",
        "Previous: " + canGoPrevious + ", Next: " + canGoNext + ", Current Index: " + this._currentDocumentIndex,
      )

      this.logExit("_updateNavigationButtons")
    },

    /**
     * Check if previous navigation is possible
     */
    _canNavigatePrevious: function () {
      return this._documentList.length > 0 && this._currentDocumentIndex > 0
    },

    /**
     * Check if next navigation is possible
     */
    _canNavigateNext: function () {
      return this._documentList.length > 0 && this._currentDocumentIndex < this._documentList.length - 1
    },
  })

  // Register the plugin
  if (!window.contentViewerPlugin) {
    window.contentViewerPlugin = {}
  }
  window.contentViewerPlugin.ContentViewerPlugin = ContentViewerPlugin

  return ContentViewerPlugin
})
