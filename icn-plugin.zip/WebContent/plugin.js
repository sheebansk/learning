/**
 * Plugin configuration file for IBM Content Navigator
 */
require(["dojo/_base/declare", "dojo/_base/lang"], (declare, lang) => {
  var pluginConfig = {
    id: "ContentViewerPlugin",
    name: "Content Viewer Plugin",
    version: "1.0.0",
    copyright: "Copyright (c) 2024 GLIC",
    description: "Adds navigation buttons and custom actions to the ICN header panel",

    // Plugin dependencies
    dependencies: [],

    // Configuration parameters
    configurationDijitClass: null,

    // Plugin load function
    load: function (callback) {
      console.log("Loading MyHeaderButtonPlugin...")

      // Load the main plugin module
      require(["contentViewerPlugin/ContentViewerPlugin"], lang.hitch(this, function (ContentViewerPlugin) {
        // Create and initialize the plugin instance
        this.pluginInstance = new ContentViewerPlugin()
        this.pluginInstance.load(callback)
      }))
    },
  }

  // Declare the ecm variable to fix the lint error
  var ecm

  // Register the plugin with ICN
  if (typeof ecm !== "undefined" && ecm.model && ecm.model.desktop) {
    ecm.model.desktop.addPlugin(pluginConfig)
  } else {
    // Store plugin config for later registration
    if (!window._pendingPlugins) {
      window._pendingPlugins = []
    }
    window._pendingPlugins.push(pluginConfig)
  }

  return pluginConfig
})
