# IBM ICN Content Viewer Plugin

This plugin adds Previous and Next navigation buttons to the IBM Content Navigator header panel for navigating through documents using external iframe communication.

## Features

- Adds Previous and Next navigation buttons to the ICN header
- Uses default IBM ICN button styling
- Navigates through documents using repositoryId, docId, vsId, and version
- Communicates with external iframe via message events
- Buttons are enabled/disabled based on document navigation context
- Responsive design that adapts to mobile screens
- Uses IBM ICN logging framework

## Installation

1. **Build the Plugin**
   \`\`\`bash
   ant build
   \`\`\`

2. **Deploy to ICN**
   - Copy the generated JAR file from `dist/ContentViewerPlugin.jar` to your ICN plugins directory
   - Or use the deploy target: `ant deploy`

3. **Configure in ICN Admin**
   - Log into ICN as an administrator
   - Go to Admin Desktop → Plug-ins
   - Click "New Plug-in" and upload the JAR file
   - Configure the plugin settings as needed

4. **Enable for Desktop**
   - Go to Admin Desktop → Desktops
   - Edit your desktop configuration
   - Add the plugin to the "Plug-ins" tab
   - Save and refresh your desktop

## Message Event Communication

The plugin communicates with external applications via `postMessage` API. When ICN is embedded as an iframe, the parent window can send messages to control document navigation.

### Incoming Message Types

#### 1. DOCUMENT_LIST
Sets the list of documents available for navigation.

\`\`\`javascript
window.frames['icn-iframe'].postMessage({
  type: 'DOCUMENT_LIST',
  documents: [
    {
      repositoryId: 'repo1',
      docId: 'doc123',
      vsId: 'vs456',
      version: '1.0'
    },
    {
      repositoryId: 'repo1',
      docId: 'doc124',
      vsId: 'vs457',
      version: '2.0'
    }
  ]
}, '*');
\`\`\`

#### 2. OPEN_DOCUMENT
Opens a specific document.

\`\`\`javascript
window.frames['icn-iframe'].postMessage({
  type: 'OPEN_DOCUMENT',
  document: {
    repositoryId: 'repo1',
    docId: 'doc123',
    vsId: 'vs456',
    version: '1.0'
  }
}, '*');
\`\`\`

#### 3. CURRENT_DOCUMENT
Sets the current document context for navigation.

\`\`\`javascript
window.frames['icn-iframe'].postMessage({
  type: 'CURRENT_DOCUMENT',
  document: {
    repositoryId: 'repo1',
    docId: 'doc123',
    vsId: 'vs456',
    version: '1.0'
  }
}, '*');
\`\`\`

### Outgoing Message Types

The plugin sends messages back to the parent window:

#### 1. NAVIGATE_PREVIOUS
Sent when user clicks Previous button.

#### 2. NAVIGATE_NEXT
Sent when user clicks Next button.

\`\`\`javascript
// Listen for navigation events from ICN
window.addEventListener('message', function(event) {
  if (event.data.source === 'ICN_CONTENT_VIEWER_PLUGIN') {
    switch(event.data.type) {
      case 'NAVIGATE_PREVIOUS':
        console.log('User navigated to previous document:', event.data.document);
        break;
      case 'NAVIGATE_NEXT':
        console.log('User navigated to next document:', event.data.document);
        break;
    }
  }
});
\`\`\`

## Button Functionality

### Previous Button
- Navigates to the previous document in the document list
- Disabled when at the first document or no documents available
- Uses `desktop.openDocument(contentItem)` to open the document
- Sends `NAVIGATE_PREVIOUS` message to parent window

### Next Button  
- Navigates to the next document in the document list
- Disabled when at the last document or no documents available
- Uses `desktop.openDocument(contentItem)` to open the document
- Sends `NAVIGATE_NEXT` message to parent window

## Document Navigation

The plugin manages document navigation through:

1. **Document List**: Received via `DOCUMENT_LIST` message
2. **Current Document**: Set via `CURRENT_DOCUMENT` message
3. **Navigation State**: Tracks current position in document list
4. **Document Opening**: Uses ICN's `ContentItem` and `desktop.openDocument()`

## Integration Example

\`\`\`html
<!DOCTYPE html>
<html>
<head>
    <title>ICN Document Viewer Integration</title>
</head>
<body>
    <iframe id="icn-viewer" src="http://icn-server/navigator" width="100%" height="600px"></iframe>
    
    <script>
        var icnFrame = document.getElementById('icn-viewer');
        var documents = [
            { repositoryId: 'repo1', docId: 'doc1', vsId: 'vs1', version: '1.0' },
            { repositoryId: 'repo1', docId: 'doc2', vsId: 'vs2', version: '1.0' },
            { repositoryId: 'repo1', docId: 'doc3', vsId: 'vs3', version: '1.0' }
        ];
        
        // Wait for iframe to load
        icnFrame.onload = function() {
            // Send document list
            icnFrame.contentWindow.postMessage({
                type: 'DOCUMENT_LIST',
                documents: documents
            }, '*');
            
            // Set current document
            icnFrame.contentWindow.postMessage({
                type: 'CURRENT_DOCUMENT',
                document: documents[0]
            }, '*');
        };
        
        // Listen for navigation events
        window.addEventListener('message', function(event) {
            if (event.data.source === 'ICN_CONTENT_VIEWER_PLUGIN') {
                console.log('Navigation event:', event.data);
            }
        });
    </script>
</body>
</html>
\`\`\`

## File Structure

\`\`\`
├── src/
│   └── com/glic/extensions/ContentViewerPlugin/
│       └── ContentViewerPlugin.java         # Java plugin class
├── WebContent/
│   ├── contentViewerPlugin.js               # Main plugin JavaScript
│   ├── plugin.js                           # Plugin configuration
│   └── contentViewerPlugin.css             # Minimal plugin styles
├── build.xml                              # Ant build script
└── README.md                              # This file
\`\`\`

## Development Notes

- Uses IBM ICN CommonActionsHandler for proper integration
- Implements IBM ICN LoggerMixin for debugging
- Buttons use default ICN styling
- Document navigation based on external message events
- Proper error handling for document operations
- Two-way communication with parent window
- No plugin.xml required - configuration handled by Java class

## Troubleshooting

1. **Buttons not appearing**: Check browser console and ICN logs
2. **Navigation not working**: Verify message events are being sent correctly
3. **Documents not opening**: Check repository access and document IDs
4. **Messages not received**: Verify iframe communication and origins
5. **Build issues**: Ensure ICN libraries path is correct in build.xml

## Browser Compatibility

- Internet Explorer 11+
- Chrome 60+
- Firefox 55+
- Safari 10+

## License

Apache License 2.0
